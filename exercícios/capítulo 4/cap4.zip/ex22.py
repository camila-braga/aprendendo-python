print ('Digite o salário.')
salario = float(input())
print ('Digite o tempo de serviço, em anos.')
tempo = float(input())

print('O imposto será:')
if salario<200:
    imposto = 0
else:
    if  salario>=200 and salario <=450:
        imposto = 0.03*salario
    else:
        if 450 < salario and salario < 700:
            imposto = 0.08*salario
        else:
            imposto = 0.12*salario
print (imposto)

print('A gratificação será:')
if salario> 500:
    if tempo <=3:
        gratificaçao = 20
    else:
        gratificação = 30
else:
    if tempo <=3:
        gratificação = 23
    else:
        if 3 < tempo and tempo < 6:
            gratificaçao = 35
        else:
            gratificaçao = 33
print (gratificaçao)

salario = salario - imposto + gratificaçao
print ('O salário líquido será', salario)

print('A categoria será:')
if salario <= 350:
    print ('A')
else:
    if 350 < salario and salario< 600:
        print ('B')
    else:
        print('C')



    

        
