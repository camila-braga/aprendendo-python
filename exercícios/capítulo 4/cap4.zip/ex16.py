print ('Qual o preço atual do produto?')
preçoatual = float(input())
print ('Qual a venda média mensal desse produto?')
vendamedmensal = float(input())

if preçoatual < 30 or vendamedmensal < 500:
    novopreço = preçoatual + 0.1*preçoatual
else:
    if 30>= preçoatual and preçoatual<80 or 500>= vendamedmensal and vendamedmensal<1200:
        novopreço = preçoatual + 0.15*preçoatual
    else:
        novopreço = preçoatual - 0.20*preçoatual

print ('Preço atualizado =', novopreço)

        
