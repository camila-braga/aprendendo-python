print ('Qual o preço?')
preço = float(input())
print ('Qual o tipo? A, L ou V')
tipo = str(input())
print ('Produto necessita de refrigeração? S para sim, N para não.')
refr = str(input())

if refr =='N':
    if tipo =='A':
        if preço < 15:
            add = 2
        else:
            add = 5
    else:
        if tipo =='L':
            if preço < 10:
                add = 1.5
            else:
                add = 2.5
        else:
            if tipo =='V':
                if preço < 30:
                    add = 3
                else:
                    add = 2.5
else:
    if refr == 'S':
        if tipo =='A':
            add = 8
        else:
            if tipo =='L':
                add = 0
            else:
                if tipo == 'V':
                    add =0
print('O valor adicional =', add)
            
if preço < 25:
    imposto = 0.05*preço
else:
    imposto = 0.08*preço
print('O valor do imposto =',imposto)

custo = preço + imposto
print('O preço de custo =', custo)

if tipo =='A' or refr =='S':
    desconto = 0
else:
    desconto = 0.03*custo
print('Desconto =', desconto)

preço = custo + add - desconto
print('Novo preço =', preço)

if preço <= 50:
    print('Barato')
else:
    if 50 < preço and preço < 100:
        print('Normal')
    else:
        print('Caro')

        
