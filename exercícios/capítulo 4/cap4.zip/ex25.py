print ('Qual o ângulo em graus?')
angulo = float(input())


if angulo >=0:
    
    voltas = int(angulo/360)
    print('Quantidade de voltas completas:',voltas)
    if angulo >0:
        print('Sentido anti-horário')
    
    if 0< angulo and angulo <90:
        print('Quadrante I')
    if angulo ==90:
        print('Eixo y>0')
    if 90<angulo and angulo <180:
        print('Quadrante II')
    if angulo==180:
        print('Eixo x<0')
    if 180<angulo and angulo<270:
        print('Quadrante III')
    if angulo==270:
        print('Eixo y<0')
    if 270<angulo and angulo<360:
        print('Quadrante IV')
    if angulo==360 or angulo==0:
        print('Eixo x>0')
    if angulo > 360:
        a = angulo - voltas*360
        if 0< a and a <90:
            print('Quadrante I')
        if a==90:
            print('Eixo y>0')
        if 90<a and a<180:
            print('Quadrante II')
        if a==180:
            print('Eixo x<0')
        if 180<a and a<270:
            print('Quadrante III')
        if a==270:
            print('Eixo y<0')
        if 270<a and a<360:
            print('Quadrante IV')
        if a==360 or a==0:
            print('Eixo x>0')
        
else:
    
    voltas = int((-angulo)/360)
    print('Quantidade de voltas completas:',voltas)
    if angulo <0:
        print('Sentido horário')
        
    if 0> angulo and angulo >-90:
        print('Quadrante IV')
    if angulo ==-90:
        print('Eixo y<0')
    if -90>angulo>-180:
        print('Quadrante III')
    if angulo==-180:
        print('Eixo x<0')
    if -180>angulo and angulo >-270:
        print('Quadrante II')
    if angulo==-270:
        print('Eixo y>0')
    if -270>angulo and angulo>-360:
        print('Quadrante I')
    if angulo==-360:
        print('Eixo x>0')
    if angulo < -360:
        a = angulo + voltas*360
        if 0> a and a>-90:
            print('Quadrante IV')
        if a==-90:
            print('Eixo y<0')
        if -90>a and a>-180:
            print('Quadrante III')
        if a==-180:
            print('Eixo x<0')
        if -180>a and a>-270:
            print('Quadrante II')
        if a==-270:
            print('Eixo y>0')
        if -270>a and a>-360:
            print('Quadrante I')
        if a==-360 or a==0:
            print('Eixo x>0')
    


    
